<!DOCTYPE HTML>
<html lang = "en">
<head>
  
  <title>NextHighFitness</title>
  <meta charset = "UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0 ">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

<!------ Sets this file as the header------>
<?php wp_head();?>


</head>
<body> 
<!------------------------------------------------------------------------------------------- Header ------------------------------------------------------------------------------>
   
   
	<div class="container">
	
		<div class="navbar">
			<div class="logo">
			<!------ Set up the images------>
				<a href="https://nexthightech.net/fitness/"><img src="<?php bloginfo('template_directory');?>\Logo\Sans titre.png" width="190px" height="120px"></a>
			</div>
		  
			<!-- Search bar -->
		<form class="search-box" method="get" action="<?php print site_url();?>">
			   <input type="text" placeholder="Search" name="s" value="<?php if(isset($_GET['s'])){print $_GET['s'];} ?>" class="search-txt">
			  <button type="submit" class="search-btn" ><i class="material-icons">search</i></button>  
		</form>	
			
			
			
			<!---Menu --->
			<?php 
		wp_nav_menu(
				array(
						'theme_location' => 'top-menu',
						'menu_id' => 'main-menu',
						'container' => 'nav',
						'menu_class' => 'navbar, container',

					)
		
		);?>
			
		<!------ Set up the images------>
		<img src="<?php bloginfo('template_directory');?>\images\iconfinder_shopping-cart_216477.png" width="30px" height="30px">
		<img src="<?php bloginfo('template_directory');?>\images\iconfinder_menu_1814109.png" class="menu_icon">
	</div> 
	</div>	
   
<!------------------------------------------------------------------------------------------- /Header ------------------------------------------------------------------------------>	


