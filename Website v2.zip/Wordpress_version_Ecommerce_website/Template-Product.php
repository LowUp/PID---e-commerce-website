<?php
/* Template Name: Product */

?>
