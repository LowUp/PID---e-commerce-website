<?php
/* Template Name: About */
get_header();
?>
<?php $hero = get_field('ab');?>
	<div class="about-body">
	 <div class="about-section">
		<div class="inner-container">
		 <h1>About Us</h1>
		 <p class="text"> 
		 We are participants in the Amazon services LLC Associates program, an affiliate advertising program design to provide a means for us to earn fees by linking to Amazon.com and affiliate sites.
		 </p>
		 <br>
		 <p class="text">Read more about:</p>
			<div class="skills">
			
				<?php if($hero['website_link']):?>
				<a href="<?php echo $hero['website_link'];?>">Website</a>
				<?php endif;?>
				
				<?php if($hero['products_link']):?>
				<a href="<?php echo $hero['products_link'];?>">Products</a>
				<?php endif;?>
				
				<?php if($hero['audience_link']):?>
				<a href="<?php echo $hero['audience_link'];?>">Audience</a>
				<?php endif;?>
				
			</div>
		</div>
	 </div>
	</div>



<?php get_footer();?>