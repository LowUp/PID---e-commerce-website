<!------------------------------------------------------------------------------------------- Body ------------------------------------------------------------------------------>
<?php get_header();?>





<?php $hero = get_field('hero');?>
<div class="header">
   
	<div class="container">
	<div class="row">
		<div class="colNo1">
		<h1>Shape it!</h1>
		<p>A wide variety of fitness products</p>
		
		<?php if($hero['link']):?>
		<a href="<?php echo $hero['link'];?>" class="btn">Shop now &#10141</a>		
		</div>
		<?php endif;?>
		
		<div class="colNo1">
		 <img src="<?php bloginfo('template_directory');?>\images\Image1.png">
		</div>
	  </div>
	</div>	
  </div>
  	
	<div class="categories">
	<h1 class="title" > Categories</h1>
	 <div class="small-container">	
		<div class="row">
			<div class="colNo3">			
				<a href="https://nexthightech.net/fitness/category/all-products/trousers/"><img src="<?php bloginfo('template_directory');?>\images\leg-3519153_1920.jpg"></a>			
				<h2>Trousers</h2>
			</div>
			<div class="colNo3">
				<a href="https://nexthightech.net/fitness/category/all-products/shirts/"><img src="<?php bloginfo('template_directory');?>\images\blank-1976334.png" height="445px"></a>
				<h2>Shirts</h2>
			</div>
			<div class="colNo3">
				<a href="https://nexthightech.net/fitness/category/all-products/sneakers/"><img src="<?php bloginfo('template_directory');?>\images\convers-625612_1280.jpg" height="445px"></a>
				<h2>Sneakers</h2>
			</div>
			
			</div>
		</div>
	 </div>

	<h1 class="title"> Top Interesting </h1>
	  

	  <div class="box">
		<div class="box-btn">
		<button> NEWEST</button>
		<button> MEN</button>
		<button> WOMEN</button>
		</div>
		  
	<!-------------------- Tab container --------------------->  
	  <div class="small-container boxContainer">
		<div class="row row2 ">
		<div class="colNo4">
		<figure class="snip1584"><img src"<a href="https://www.amazon.co.uk/KOOKABURRA-Unisexs-Players-Cricket-Trousers/dp/B07QDTYTG8?dchild=1&keywords=trousers&qid=1619041922&s=sports&sr=1-4&linkCode=li2&tag=170c6-21&linkId=fa7dffc8c6364f347053696da34f676d&language=en_GB&ref_=as_li_ss_il" target="_blank"><img border="0" src="//ws-eu.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B07QDTYTG8&Format=_SL160_&ID=AsinImage&MarketPlace=GB&ServiceVersion=20070822&WS=1&tag=170c6-21&language=en_GB" ></a><img src="https://ir-uk.amazon-adsystem.com/e/ir?t=170c6-21&language=en_GB&l=li2&o=2&a=B07QDTYTG8" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />">	
		<figcaption> 
		 <h3>Learn more</h3>
		 </figcaption><a href="https://amzn.to/3v9hqgx"></a>
		</figure>
			<h4>Kookaburra Unisex Pro Players Cricket Trousers</h4>
		</div>
		
		  
	  
		<div class="colNo4">
		<figure class="snip1584"><img <a href="https://www.amazon.co.uk/icyzone-Workout-Tank-Tops-Women/dp/B083F9GNSQ?pd_rd_w=XKRN4&pf_rd_p=f1512742-6a19-4088-9827-09f4d3d40791&pf_rd_r=MZFE6DFJYJZJWXJF3N8A&pd_rd_r=01cfadca-c450-45aa-abda-3578cf317fb6&pd_rd_wg=twmA3&pd_rd_i=B07TCXV312&psc=1&linkCode=li2&tag=170c6-21&linkId=db2fab05cfe2ddf67bccbb71fd4e9ea0&language=en_GB&ref_=as_li_ss_il" target="_blank"><img border="0" src="//ws-eu.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B083F9GNSQ&Format=_SL160_&ID=AsinImage&MarketPlace=GB&ServiceVersion=20070822&WS=1&tag=170c6-21&language=en_GB" ></a><img src="https://ir-uk.amazon-adsystem.com/e/ir?t=170c6-21&language=en_GB&l=li2&o=2&a=B083F9GNSQ" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />>	
		<figcaption> 
		 <h3>Learn more</h3>
		 </figcaption><a href="https://amzn.to/3vaEMmc"></a>
		</figure>
			<h4>icyzone Workout Tank Tops for Women - Athletic Yoga Tops, Racerback Running Tank Top</h4>
		</div>
		
		  
	  
		<div class="colNo4">
		<figure class="snip1584"><img <a href="https://www.amazon.co.uk/Under-Armour-Comfortable-Sweatband-Breathable/dp/B071Z8574W?dchild=1&keywords=hat&qid=1619042709&s=sports&sr=1-6&linkCode=li2&tag=170c6-21&linkId=f0aeaa2c93d25e9516fbf40cb76e0af2&language=en_GB&ref_=as_li_ss_il" target="_blank"><img border="0" src="//ws-eu.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B071Z8574W&Format=_SL160_&ID=AsinImage&MarketPlace=GB&ServiceVersion=20070822&WS=1&tag=170c6-21&language=en_GB" ></a><img src="https://ir-uk.amazon-adsystem.com/e/ir?t=170c6-21&language=en_GB&l=li2&o=2&a=B071Z8574W" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />>	
		<figcaption> 
		 <h3>Learn more</h3>
		 </figcaption><a href="https://amzn.to/3dFxVLG"></a>
		</figure>
		  <h4>Under Armour Men's Blitzing 3.0 Cap Hat</h4>
		</div>
		
		  
	  
		<div class="colNo4">
		<figure class="snip1584"><img <a href="https://www.amazon.co.uk/dp/B00KWKD2TY?th=1&linkCode=li2&tag=170c6-21&linkId=64351c68e677c914de200e374712b5a1&language=en_GB&ref_=as_li_ss_il" target="_blank"><img border="0" src="//ws-eu.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B00KWKD2TY&Format=_SL160_&ID=AsinImage&MarketPlace=GB&ServiceVersion=20070822&WS=1&tag=170c6-21&language=en_GB" ></a><img src="https://ir-uk.amazon-adsystem.com/e/ir?t=170c6-21&language=en_GB&l=li2&o=2&a=B00KWKD2TY" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />>	
		<figcaption> 
		 <h3>Learn more</h3>
		 </figcaption><a href="https://amzn.to/3n84tkp"></a>
		</figure>
		  <h4>Under Armour Men's Raid Hybrid Shorts</h4>
		</div>
		
		</div>	
	  </div>
		
	  <!-------------------- Tab container --------------------->  
	  <div class="small-container boxContainer">	
	  <h1> deuxième</h1>
		
	  </div>
		  
	 <!-------------------- Tab container --------------------->  
	  <div class="small-container boxContainer">	
	  <h1> Dernier</h1>
		
	  </div>
		  
	</div>
				

<?php get_footer();?>
<!------------------------------------------------------------------------------------------- /Body ------------------------------------------------------------------------------>

