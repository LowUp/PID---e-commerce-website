<?php

function load_stylesheet()
{
	
	wp_register_style('custom', get_template_directory_uri() .'/style.css', array(),rand(111,9999),'all');
	wp_enqueue_style('custom');
	
	
}
add_action('wp_enqueue_scripts', 'load_stylesheet');


// Register menus
add_theme_support('menus') ;


//Register menus
register_nav_menus(
	
		array(
		
			'top-menu' => __('Menu', 'theme'), 
		)

);

// Load js files
function toggle_menu(){
	//Makes Js load faster
	if (!is_admin()) {
      wp_deregister_script('toggle');
      wp_register_script('toggle', get_stylesheet_directory_uri() . '/js/script.js', array('jquery'), rand(111,9999),false);
      wp_enqueue_script('toggle');
   }
	/*wp_enqueue_script('toggle', get_stylesheet_directory_uri() . '/js/script.js', array('jquery'), rand(111,9999),false);*/
}
add_action('wp_enqueue_scripts', 'toggle_menu');


/**
 * Add a sidebar.
 */
add_action( 'widgets_init', 'wpdocs_theme_slug_widgets_init' );
function wpdocs_theme_slug_widgets_init() {
    register_sidebar( array(
        'name'          => 'Main Sidebar',
        'id'            => 'sidebar-1'
        
    ) );
}

/**
 * Validation for search feature.
 * Disable search when search bar is empty 
 */
/*add_filter( 'request', 'my_request_filter' );
function my_request_filter( $query_vars ) {
    if( isset( $_GET['s'] ) && empty( $_GET['s'] ) ) {
        $query_vars['s'] = " ";
        global $no_search_results;
        $no_search_results = TRUE;
    }
    return $query_vars;
}*/