jQuery(document).ready(function(){
  	//JQuery function for toggle menu
	jQuery(".menu_icon").click(function(){
    if(jQuery("nav ul").css({"max-height": "200px"}))
	{jQuery("nav ul").fadeToggle();}
  });
	
	//Check to see if the window is top if not then display button
    jQuery(window).scroll(function(){
        if (jQuery(this).scrollTop() > 100) {
            jQuery('#scrollTop').fadeIn();
        } else {
            jQuery('#scrollTop').fadeOut();
        }
    });

    //Click event to scroll to top
    jQuery('#scrollTop').click(function(){
        jQuery('html, body').animate({scrollTop : 0},800);
        return false;
    });
	
	/* Tab feature */
	jQuery('.boxContainer:first').show();
	jQuery('.box-btn button:first').addClass('active');
	
	jQuery('.box-btn button').click(function(event){
	
		index = jQuery(this).index();
		jQuery('.box-btn button').removeClass('active');
		jQuery(this).addClass('active');
		jQuery('.boxContainer').hide();
		jQuery('.boxContainer').eq(index).show();
		
	});
	
});
