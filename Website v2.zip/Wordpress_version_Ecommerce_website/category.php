<?php
/**
 * Template Name: Category
 */
 
get_header(); ?>
              
<div class="small-container sidebar-template-content">
	
	<!-- Displays the category name -->
	<?php $category = get_queried_object();?>
	  <h2> <?php echo $category->cat_name;?> </h2>
	
	
	<!-----------------displays the sidebar ----------------------->
	<br>
	<br>
 <div class="sidebar sidebar-template-side">
	 <?php get_sidebar();?>
 </div>
	
    <div class="row row2">
 	
    <?php

		
	$paged = (get_query_var( 'paged' )) ? get_query_var( 'paged' ) : 1;
    $args = array(
    'post_type' => 'post',
    'post_status' => 'publish',
    //'category_name' => 'Pants'
	'cat' => $category->term_id, //get the id of the currend category
    'posts_per_page' => 8,
	'paged' => $paged,
);
    $arr_posts = new WP_Query( $args );
		
		
 // loop to display posts from a specific category or post type
    if ( $arr_posts->have_posts() ) :
 
        while ( $arr_posts->have_posts() ) :
            $arr_posts->the_post();
            ?>
		
            <div class="colNo4">
		
		<!-- displays both paragraph and html content-->
		<figure class="snip1584"><img <?php the_content();?> >
		<figcaption> 
	
		 <h3>Learn more</h3>
		 			
		 </figcaption><a href="<?php echo get_the_excerpt();?>"></a>
		</figure>
				
		<!-- displays the title and permalink-->
		<a href="<?php// the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title() ?></a>
	
		
			</div>
		
            <?php
        endwhile;
		/*Displays a page navigation when more than 8 posts are presented on a page*/
			wp_pagenavi(array( 'query' => $arr_posts )); 	
			
		endif;
			
    ?>
 
	</div>
	<?php// } ?>
</div>
 
<?php get_footer(); ?>