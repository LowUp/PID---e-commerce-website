<?php get_header(); ?>
<div class="small-container">
<h2>Search Results:</h2>
	<div class="row row2">

	<?php
		
		$term = $_GET['s'];

		$expTerm = explode(" ",$term); // array that stores each term in one index value 

		
		$search = "(";
		foreach($expTerm as $ek=>$ev)
		{
			if($ek == 0)
			{
				$search .= " post_title LIKE '%".$ev."%' ";
			}
			else
			{
				$search .= " OR post_title LIKE '%".$ev."%'";
			}
		}
		$search .= ")";
		
		$query = $wpdb->get_results(" SELECT * FROM ".$wpdb->prefix."posts WHERE post_status='publish' AND $search ");

		/* build a position array for the term */
		$position = 101;
		$rate = [];
		
		for($i=0; $i<=100; $i++)
		{
			$position = $position - 1; // first run will equal 100
			$rate[$i] = $position;
		}

		/* build the array based on type and position */
		/* loop through the query */
		$newArray = [];
		foreach($query as $k=>$v)
		{
			$title = $v->post_title;
			/* loop though each term */
			$calculate = 0;
			foreach($expTerm as $tk=>$tv)
			{
				if(strpos(strtolower($title), strtolower($tv)) !== false)
				{
					$calculate = $calculate + strlen($tv);

					$pos = strpos(strtolower($title), strtolower($tv));
					$calculate = $calculate + $rate[$pos];

				} // end of if statement
			} // end of the for each term

			$newKey = $calculate.'.'.$v->ID;

			$newArray[$newKey] = $v;

			//print $newKey.'<br />';

		} // end of for each result or query

		/* sort in reverse DESC */
		krsort($newArray);
		
		

	foreach($query as $qk=>$qv)
	{
		?>
		<div class="colNo4">
	<p><?php print $qv->post_content;?></p>
	<p><?php print $qv->post_title; ?></p>
		</div>

		
 	
		<?php
	}
   ?>
	</div>
	</div>
	
	<?php



?>







<?php get_footer(); ?>